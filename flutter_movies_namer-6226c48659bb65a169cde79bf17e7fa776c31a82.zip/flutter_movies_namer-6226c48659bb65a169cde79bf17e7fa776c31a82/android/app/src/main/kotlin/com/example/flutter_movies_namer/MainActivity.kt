package com.example.flutter_movies_namer

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
